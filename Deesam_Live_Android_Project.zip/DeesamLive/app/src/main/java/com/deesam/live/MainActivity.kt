package com.deesam.live

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.*
import java.util.Locale

private val Purple = Color(0xFF6C4CF1)
private val Dark = Color(0xFF15121D)

data class LiveRoom(val title: String, val host: String, val listeners: Int, val country: String)

class MainActivity : ComponentActivity() {
    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        setContent { DeesamLiveApp() }
    }
}

@Composable
fun DeesamLiveApp() {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = lightColorScheme(primary = Purple)) {
        NavHost(navController = nav, startDestination = "home") {
            composable("home") { HomeScreen(nav) }
            composable("room/{title}") { backStack ->
                val title = backStack.arguments?.getString("title") ?: "Live Room"
                RoomScreen(title, nav)
            }
            composable("tasks") { TasksScreen(nav) }
            composable("wallet") { WalletScreen(nav) }
            composable("referral") { ReferralScreen(nav) }
            composable("coinseller") { CoinsellerScreen(nav) }
            composable("checkin") { CheckInScreen(nav) }
            composable("profile") { ProfileScreen(nav) }
        }
    }
}

@Composable
fun AppScaffold(title: String, nav: NavHostController, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) }
                }
            )
        }
    ) { p -> Column(Modifier.padding(p).fillMaxSize().padding(16.dp), content = content) }
}

@Composable
fun HomeScreen(nav: NavHostController) {
    val rooms = listOf(
        LiveRoom("African Music & Vibes", "Aisha", 128, "🇰🇪"),
        LiveRoom("Night Talk Kenya", "Kevin", 76, "🇰🇪"),
        LiveRoom("Naija Entertainment", "Chidi", 204, "🇳🇬"),
        LiveRoom("Ghana Chat Room", "Ama", 59, "🇬🇭")
    )
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Deesam Live", fontWeight = FontWeight.ExtraBold) },
                actions = {
                    IconButton({ nav.navigate("wallet") }) { Icon(Icons.Default.AccountBalanceWallet, "Wallet") }
                }
            )
        },
        bottomBar = { BottomBar(nav, "home") }
    ) { p ->
        LazyColumn(
            Modifier.padding(p).fillMaxSize().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(Modifier.height(8.dp))
                Text("Good day 👋", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Listen, connect and earn beans.", color = Color.Gray)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    QuickButton("🎁 Tasks", { nav.navigate("tasks") })
                    QuickButton("📅 Check-in", { nav.navigate("checkin") })
                    QuickButton("👥 Invite", { nav.navigate("referral") })
                }
                Spacer(Modifier.height(12.dp))
                Text("Live now", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            items(rooms) { room ->
                Card(
                    Modifier.fillMaxWidth().clickable {
                        nav.navigate("room/${room.title.replace("/", "_")}")
                    },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(54.dp).background(Purple.copy(alpha=.12f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) { Text(room.country, fontSize = 24.sp) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(room.title, fontWeight = FontWeight.Bold)
                            Text("${room.host} • ${room.listeners} listeners", color = Color.Gray)
                        }
                        Text("LIVE", color = Color.White, modifier = Modifier.background(Color.Red, RoundedCornerShape(8.dp)).padding(8.dp,4.dp), fontSize=11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun QuickButton(label: String, onClick: () -> Unit) {
    Button(onClick, modifier = Modifier.height(42.dp)) { Text(label) }
}

@Composable
fun BottomBar(nav: NavHostController, current: String) {
    NavigationBar {
        NavigationBarItem(current=="home", { nav.navigate("home") }, icon={Icon(Icons.Default.Home,null)}, label={Text("Home")})
        NavigationBarItem(false, { nav.navigate("tasks") }, icon={Icon(Icons.Default.EmojiEvents,null)}, label={Text("Tasks")})
        NavigationBarItem(false, { nav.navigate("wallet") }, icon={Icon(Icons.Default.AccountBalanceWallet,null)}, label={Text("Wallet")})
        NavigationBarItem(false, { nav.navigate("profile") }, icon={Icon(Icons.Default.Person,null)}, label={Text("Me")})
    }
}

@Composable
fun RoomScreen(title: String, nav: NavHostController) {
    var muted by remember { mutableStateOf(false) }
    var beans by remember { mutableIntStateOf(0) }
    AppScaffold(title, nav) {
        Box(Modifier.fillMaxWidth().height(220.dp).background(Dark, RoundedCornerShape(24.dp)), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                Box(Modifier.size(86.dp).background(Purple, CircleShape), contentAlignment=Alignment.Center) { Text("🎙️", fontSize=38.sp) }
                Spacer(Modifier.height(8.dp))
                Text("LIVE AUDIO", color=Color.White, fontWeight=FontWeight.Bold)
                Text("Real-time room • 64 listeners", color=Color.LightGray)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Room actions", fontWeight=FontWeight.Bold, fontSize=18.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button({ muted=!muted }, Modifier.weight(1f)) { Icon(if(muted) Icons.Default.MicOff else Icons.Default.Mic,null); Spacer(Modifier.width(6.dp)); Text(if(muted) "Unmute" else "Mute") }
            Button({ beans += 1000 }, Modifier.weight(1f)) { Text("🎁 Gift 1K") }
        }
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Your beans", fontWeight=FontWeight.Bold)
                Text(String.format(Locale.US, "%,d beans", beans), fontSize=28.sp, fontWeight=FontWeight.ExtraBold, color=Purple)
                Text("Gifts and host earnings are settled by the backend.", color=Color.Gray, fontSize=12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Room chat", fontWeight=FontWeight.Bold, fontSize=18.sp)
        Text("Welcome to the room! Be respectful and have fun.", color=Color.Gray)
    }
}

@Composable
fun TasksScreen(nav: NavHostController) {
    var claimed by remember { mutableStateOf(false) }
    AppScaffold("Task Center", nav) {
        Text("Earn beans by completing activities.", color=Color.Gray)
        Spacer(Modifier.height(12.dp))
        TaskCard("2-hour listening task", "2,000 beans", "Spend 2 hours in eligible rooms", claimed) { claimed=true }
        TaskCard("Daily check-in", "Up to 7,000 beans", "Check in every day", false) { nav.navigate("checkin") }
        TaskCard("Invite a friend", "1,000 beans", "Invite a new verified user", false) { nav.navigate("referral") }
        TaskCard("Become a coinseller", "Commission", "Apply and complete verification", false) { nav.navigate("coinseller") }
    }
}

@Composable
fun TaskCard(name:String, reward:String, detail:String, done:Boolean, onClick:()->Unit) {
    Card(Modifier.fillMaxWidth().padding(vertical=6.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(name, fontWeight=FontWeight.Bold)
                Text(detail, color=Color.Gray, fontSize=13.sp)
                Text(reward, color=Purple, fontWeight=FontWeight.Bold)
            }
            Button(onClick, enabled=!done) { Text(if(done) "Claimed" else "Open") }
        }
    }
}

@Composable
fun WalletScreen(nav: NavHostController) {
    var beans by remember { mutableLongStateOf(125000) }
    AppScaffold("Wallet", nav) {
        Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=Dark)) {
            Column(Modifier.padding(22.dp)) {
                Text("Bean balance", color=Color.LightGray)
                Text(String.format(Locale.US, "%,d", beans), color=Color.White, fontSize=36.sp, fontWeight=FontWeight.ExtraBold)
                Text("≈ $${"%.2f".format(beans / 10000.0)}", color=Color(0xFFBFAFFF))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Conversion", fontWeight=FontWeight.Bold)
        Text("10,000 beans = $1 • 100,000 beans = $10")
        Text("Minimum withdrawal: 100,000 beans ($10)", color=Color.Gray)
        Spacer(Modifier.height(18.dp))
        Button(onClick = { if (beans >= 100000) beans -= 100000 }, enabled = beans >= 100000, modifier=Modifier.fillMaxWidth()) {
            Text("Withdraw $10+")
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton({ nav.navigate("coinseller") }, Modifier.fillMaxWidth()) { Text("Coinseller Center") }
    }
}

@Composable
fun ReferralScreen(nav: NavHostController) {
    AppScaffold("Invite & Earn", nav) {
        Text("Your invitation link", fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth().padding(vertical=12.dp)) {
            Text("https://deesam.live/invite/DEESAM100", Modifier.padding(16.dp))
        }
        Button({ }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Share,null); Spacer(Modifier.width(8.dp)); Text("Share invitation") }
        Spacer(Modifier.height(20.dp))
        Text("Referral reward", fontWeight=FontWeight.Bold, fontSize=18.sp)
        Text("Earn beans when a new invited user registers, verifies and completes eligible activities.")
    }
}

@Composable
fun CheckInScreen(nav: NavHostController) {
    var day by remember { mutableIntStateOf(1) }
    AppScaffold("Daily Check-in", nav) {
        Text("7-day streak", fontSize=24.sp, fontWeight=FontWeight.Bold)
        Text("Day $day of 7", color=Purple)
        Spacer(Modifier.height(18.dp))
        (1..7).forEach {
            val reward = it * 1000
            ListItem(
                headlineContent={Text("Day $it")},
                supportingContent={Text("$reward beans")},
                trailingContent={ if(it==day) { { Button({ day = minOf(7, day+1) }) { Text("Claim") } } } else null }
            )
            HorizontalDivider()
        }
    }
}

@Composable
fun CoinsellerScreen(nav: NavHostController) {
    AppScaffold("Coinseller Center", nav) {
        Text("Sell beans/coins to users through approved recharge channels.", color=Color.Gray)
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Coinseller application", fontWeight=FontWeight.Bold, fontSize=18.sp)
                Text("Verification is required before selling. Inventory, payments and commissions are controlled by the platform backend.", color=Color.Gray)
                Spacer(Modifier.height(12.dp))
                Button({ }) { Text("Apply to become a coinseller") }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Status: Not verified", fontWeight=FontWeight.Bold)
    }
}

@Composable
fun ProfileScreen(nav: NavHostController) {
    AppScaffold("My Profile", nav) {
        Box(Modifier.size(90.dp).background(Purple.copy(alpha=.15f), CircleShape), contentAlignment=Alignment.Center) { Text("👤", fontSize=42.sp) }
        Spacer(Modifier.height(12.dp))
        Text("Deesam User", fontSize=24.sp, fontWeight=FontWeight.Bold)
        Text("Kenya 🇰🇪", color=Color.Gray)
        Spacer(Modifier.height(20.dp))
        OutlinedButton({ nav.navigate("referral") }, Modifier.fillMaxWidth()) { Text("My referrals") }
        OutlinedButton({ nav.navigate("coinseller") }, Modifier.fillMaxWidth()) { Text("Coinseller Center") }
        OutlinedButton({ nav.navigate("wallet") }, Modifier.fillMaxWidth()) { Text("Wallet & withdrawals") }
    }
}
