# Deesam Live Android

African-focused audio live-streaming Android application foundation.

## Included
- Audio live-room UI
- Microphone permission
- Home/live discovery
- Beans wallet
- 10,000 beans = $1 rule
- 100,000 beans ($10) minimum withdrawal
- Task Center with 2-hour / 2,000-bean task
- Daily check-in
- Invitation/referral area
- Coinseller center
- Country-oriented product structure
- Navigation and Material 3 UI

## Build
Open this folder in Android Studio and let Gradle sync. Then run the `app` configuration on an Android device/emulator.

## Important
The UI is a runnable Android client foundation. Real multi-user audio streaming, authentication, server-side beans accounting, gift settlement, coinseller inventory, fraud prevention and country-specific withdrawals require a backend and a real-time audio provider/signaling service. Do not store or trust wallet balances only on the phone.

## Suggested production backend
- Authentication/user service
- Live-room service + WebRTC/LiveKit/Agora-style audio provider
- PostgreSQL/MySQL ledger
- Redis for presence/rankings
- Secure wallet ledger
- Admin/coinseller dashboard
- Payout integrations per country
- Server-side task/check-in/referral rules
